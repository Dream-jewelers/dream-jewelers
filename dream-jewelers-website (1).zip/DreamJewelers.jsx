import React from "react";

export default function DreamJewelers() {
  return (
    <div style={{ fontFamily: 'Arial', padding: '20px' }}>
      <h1>Dream JEWELER'S</h1>
      <div style={{ marginTop: '20px' }}>
        <img src="./classic-necklace.jpg" alt="Classic Necklace" width="300" />
        <h2>Classic Necklace</h2>
        <p>Price: ₹1000/-</p>
        <a href="https://wa.me/918129352352?text=I%20want%20to%20order%20the%20Classic%20Necklace">
          <button style={{ padding: '10px 20px', marginTop: '10px' }}>Order on WhatsApp</button>
        </a>
      </div>
      <footer style={{ marginTop: '50px' }}>
        <p>WhatsApp: 8129352352</p>
        <p>Email: dreamenterprisesa1@gmail.com</p>
      </footer>
    </div>
  );
}