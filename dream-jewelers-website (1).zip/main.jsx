import React from "react";
import ReactDOM from "react-dom/client";
import DreamJewelers from "./DreamJewelers.jsx";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<DreamJewelers />);