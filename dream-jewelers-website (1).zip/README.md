# Dream JEWELER'S

This is a simple React-based website for **Dream JEWELER'S** featuring a product catalog and WhatsApp ordering.

## Features

- Product display with images and prices
- WhatsApp "Order Now" integration
- Contact info in the footer

## How to Run

1. Clone the repository or download the code.
2. Use any static server or deploy it using [Vercel](https://vercel.com).
3. The main entry file is `index.html` which loads React components.

## Contact

- WhatsApp: 8129352352 (orders only)
- Email: dreamenterprisesa1@gmail.com